import React, { useState, useEffect } from 'react';
import { PORTFOLIO_DATA } from '../data/portfolioData';
import { Download, ArrowRight, ArrowUpRight, Github, Linkedin, Mail, MapPin } from 'lucide-react';

interface HeroProps {
  onOpenResumeModal: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onOpenResumeModal }) => {
  const [offset, setOffset] = useState({ x: 0, y: 0 });

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      // Extremely subtle, restrained micro-parallax (max 3-4px)
      const x = ((e.clientX / window.innerWidth) - 0.5) * 8;
      const y = ((e.clientY / window.innerHeight) - 0.5) * 8;
      setOffset({ x, y });
    };

    window.addEventListener('mousemove', handleMouseMove, { passive: true });
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  return (
    <section 
      id="home" 
      className="relative min-h-[92vh] sm:min-h-screen flex items-center justify-center pt-24 pb-16 px-4 sm:px-6 lg:px-8 overflow-hidden"
    >
      <div 
        className="max-w-4xl mx-auto w-full text-center space-y-8 relative z-10 transition-transform duration-700 ease-out"
        style={{
          transform: `translate3d(${offset.x}px, ${offset.y}px, 0)`,
        }}
      >
        
        {/* Small Top Label */}
        <div className="inline-flex items-center gap-2 px-3 py-1 bg-white/[0.04] border border-white/10 rounded-sm backdrop-blur-sm">
          <span className="w-1.5 h-1.5 rounded-full bg-sky-400 animate-pulse" />
          <span className="text-[11px] sm:text-xs font-mono tracking-widest text-slate-300 uppercase">
            Artificial Intelligence • Data • Business
          </span>
        </div>

        {/* Candidate Name Heading */}
        <div className="space-y-3">
          <h1 className="font-display text-4xl sm:text-6xl md:text-7xl font-extrabold tracking-tight text-white uppercase leading-[1.05]">
            PRIYANSHU BORKAR
          </h1>

          {/* Supporting Line */}
          <p className="font-display text-lg sm:text-2xl md:text-3xl font-medium text-sky-400 tracking-tight">
            Turning Data & Technology into Meaningful Insights.
          </p>
        </div>

        {/* Short Description */}
        <p className="max-w-2xl mx-auto text-sm sm:text-base md:text-lg text-slate-300 leading-relaxed font-normal">
          B.Tech Artificial Intelligence Engineering student building toward Data Analytics and Business Analytics, with a strong foundation in AI, programming and problem solving.
        </p>

        {/* Primary Buttons & Secondary Link */}
        <div className="pt-2 flex flex-col sm:flex-row items-center justify-center gap-4">
          <a
            href="#projects"
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-7 py-3 text-xs sm:text-sm font-semibold text-white bg-sky-600 hover:bg-sky-500 rounded-sm transition-all duration-200 shadow-sm hover:shadow-sky-500/20 active:translate-y-0.5"
          >
            <span>View My Work</span>
            <ArrowRight className="w-4 h-4" />
          </a>

          <a
            href={PORTFOLIO_DATA.personal.resumeUrl}
            download={PORTFOLIO_DATA.personal.resumeFileName}
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-7 py-3 text-xs sm:text-sm font-semibold text-slate-200 hover:text-white bg-[#12161f] hover:bg-[#1a202c] border border-white/10 rounded-sm transition-all duration-200 active:translate-y-0.5"
            title="Download Priyanshu's Resume PDF directly"
          >
            <Download className="w-4 h-4 text-sky-400" />
            <span>Download Resume</span>
          </a>

          <a
            href="#contact"
            className="group inline-flex items-center gap-1.5 px-4 py-3 text-xs sm:text-sm font-medium text-slate-300 hover:text-white transition-colors"
          >
            <span>Let's Connect</span>
            <ArrowUpRight className="w-4 h-4 text-slate-400 group-hover:text-sky-400 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
          </a>
        </div>

        {/* Minimal Credential Substrip */}
        <div className="pt-6 flex flex-wrap items-center justify-center gap-x-5 gap-y-2 text-xs font-mono text-slate-400">
          <span className="flex items-center gap-1.5">
            <span className="text-slate-500">College:</span>
            <span className="text-slate-200 font-medium">JDCOEM Nagpur</span>
          </span>
          <span className="text-slate-700 hidden sm:inline">|</span>
          <span className="flex items-center gap-1.5">
            <span className="text-slate-500">CGPA:</span>
            <span className="text-sky-400 font-semibold">8.72</span>
          </span>
          <span className="text-slate-700 hidden sm:inline">|</span>
          <span className="flex items-center gap-1.5">
            <span className="text-slate-500">Graduation:</span>
            <span className="text-slate-200">2027</span>
          </span>
          <span className="text-slate-700 hidden sm:inline">|</span>
          <span className="flex items-center gap-1.5">
            <MapPin className="w-3 h-3 text-slate-500" />
            <span>Nagpur, India</span>
          </span>
        </div>

        {/* Social Direct Links */}
        <div className="pt-2 flex items-center justify-center gap-6 text-xs text-slate-400">
          <a
            href={PORTFOLIO_DATA.personal.linkedinUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1.5 hover:text-sky-400 transition-colors"
          >
            <Linkedin className="w-3.5 h-3.5" />
            <span>LinkedIn</span>
          </a>
          <span className="text-slate-700">·</span>
          <a
            href={PORTFOLIO_DATA.personal.githubUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1.5 hover:text-white transition-colors"
          >
            <Github className="w-3.5 h-3.5" />
            <span>GitHub</span>
          </a>
          <span className="text-slate-700">·</span>
          <a
            href={`mailto:${PORTFOLIO_DATA.personal.email}`}
            className="flex items-center gap-1.5 hover:text-white transition-colors font-mono"
          >
            <Mail className="w-3.5 h-3.5" />
            <span>Email</span>
          </a>
        </div>

      </div>
    </section>
  );
};
